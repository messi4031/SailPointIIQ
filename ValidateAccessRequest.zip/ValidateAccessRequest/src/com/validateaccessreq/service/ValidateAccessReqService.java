package com.validateaccessreq.service;

import javax.ws.rs.core.*;
import sailpoint.object.*;
import sailpoint.tools.*;
import sailpoint.api.*;
import java.util.*;
import sailpoint.api.SailPointContext;
import sailpoint.api.SailPointFactory;
import sailpoint.object.Identity;
import sailpoint.spring.SpringStarter;
import sailpoint.tools.GeneralException;
import org.apache.commons.logging.*;

public class ValidateAccessReqService
{
    private static final Log log;
    
    public Response validateItems(final Map<String, Object> map) {
        ValidateAccessReqService.log.trace((Object)"Entry ValidateAccessReqService::validateItems");
        Response response = Response.ok().build();
        //SpringStarter starter = new SpringStarter("iiqBeans"); 
        try {      
      	  	SailPointContext context = SailPointFactory.createContext();      	  
           // final SailPointContext currentContext = SailPointFactory.getCurrentContext();        	       	 
            ValidateAccessReqService.log.trace((Object)("accessReqItems: " + map));
            map.put("logger", ValidateAccessReqService.log);
            map.put("context", context);
            map.put("requestor", context.getObjectByName(Identity.class, "spadmin"));
            final Object runRule = context.runRule((Rule)context.getObjectByName(Rule.class, "ACU-Rule-ValidateAccessRequest"), (Map)map);
            if (runRule != null) {
                final List otol = Util.otol(runRule);
                if (!Util.isEmpty((Collection)otol)) {
                    ValidateAccessReqService.log.debug((Object)("Error List: " + otol));
                    response = Response.ok().entity((Object)otol).build();
                }
            }
            
        }
        catch (GeneralException ex) {
            ValidateAccessReqService.log.error((Object)("GeneralException in ValidateAccessReqService::validateItems: " + ex));
        }
        ValidateAccessReqService.log.trace((Object)"Exit ValidateAccessReqService::validateItems");
        return response;
    }
    
    static {
        log = LogFactory.getLog("com.plugin.validateAccessRequest");
    }
}
