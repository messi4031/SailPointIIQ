package com.validateaccessreq.utility;

public class ValidateAccessReqConstants
{
    public static final String PLUGIN_NAME = "validateAccessRequest";
    public static final String LOGGER_NAME = "com.plugin.validateAccessRequest";
    public static final String VALIDATE_ITEMS = "validateItems";
    public static final String VALIDATION_RULE = "Validate Access Request";
}
