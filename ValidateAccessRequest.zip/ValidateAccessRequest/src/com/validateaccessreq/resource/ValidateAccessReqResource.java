package com.validateaccessreq.resource;

import java.util.*;
import javax.ws.rs.core.*;
import com.validateaccessreq.service.*;
import sailpoint.rest.plugin.*;
import javax.ws.rs.*;
import org.apache.commons.logging.*;

@Path("validateAccessRequest")
public class ValidateAccessReqResource extends BasePluginResource
{
    private static final Log log;
         
    @POST    
    @Path("validateItems")
    @AllowAll
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    public Response validateAccessRequest(final Map<String, Object> map) {
        ValidateAccessReqResource.log.trace((Object)"Entry ValidateAccessReqResource::validateAccessRequest");
        final Response validateItems = new ValidateAccessReqService().validateItems((Map)map);
        ValidateAccessReqResource.log.trace((Object)"Exit ValidateAccessReqResource::validateAccessRequest");
        return validateItems;
    }
    static {
        log = LogFactory.getLog("com.plugin.validateAccessRequest");
    }
    
    @Override
    public String getPluginName() {	
    	return "validateAccessRequest";
    }
}
