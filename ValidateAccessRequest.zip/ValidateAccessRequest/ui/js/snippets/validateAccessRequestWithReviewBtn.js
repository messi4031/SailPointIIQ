const VALIDATE_REQUEST_BASE_PATH = "validateAccessRequest";
let showReview = true;

function removeValidationDiv() {
	if (document.getElementById("validationErrorMsg") != undefined) {
		document.getElementById("validationErrorMsg").remove();
	}
}

function createErrorList(errors) {
	let errorListDiv = '<ul class="warning-message-left-padding">';
	for (let error of errors) {
		errorListDiv = errorListDiv.concat('<li>' + error + '</li>');
	}
	errorListDiv = errorListDiv.concat('</ul>');
	jQuery("#validationErrorList")[0].outerHTML = errorListDiv;
}

function showError(errors) {
	removeValidationDiv();
	jQuery("#selectedIdentitiesTopBtn").parent()
		.append(
			'<div id="validationErrorMsg" class="reader-error row">' +
			'<div class="col-xs-12">' +
			'<div class="alert alert-danger m-b-none m-t">' +
			'<h4><i class="fa fa-minus-circle m-r-sm" role="presentation"></i> #{msgs.err_validation}</h4>' +
			'<div id="validationErrorList">' +
			'</div>' +
			'</div>' +
			'</div>' +
			'</div>');
	createErrorList(errors);
}

function validateItems(items) {
	let url = PluginHelper.getPluginRestUrl(VALIDATE_REQUEST_BASE_PATH + "/validateItems");
	jQuery.ajax({
		type: "POST",
		async: true,
		beforeSend: function(request) {
			request.setRequestHeader("X-XSRF-TOKEN", PluginHelper.getCsrfToken());
		},
		contentType: 'application/json',
		url: url,
		data: angular.toJson(items),
		success: function(data) {
			if (data != undefined && data != "") {
				showError(data);
				document.getElementById("validationErrorMsg")
					.scrollIntoView({ behavior: "smooth" });
			}
			else {
				removeValidationDiv();
				getSelectedItems(items.addedItems, items.removedItems);
			}
		},
		error: function(response, status, error) {
			console.log("response: " + response);
			console.log("status: " + status);
			console.log("error: " + error);
		}
	});
}

function getSelectedItems(oldAddedItems, oldRemovedItems) {
	let ctrl = angular.element('[ng-controller="AccessRequestReviewCtrl as reviewCtrl"]').scope();
	if (ctrl.reviewCtrl != undefined) {
		let dataMap = {};
		let addedItems = ctrl.reviewCtrl.getTopLevelRequestedItems();
		if (addedItems != undefined && addedItems.length > 0 && JSON.stringify(addedItems) != JSON.stringify(oldAddedItems)) {
			dataMap.addedItems = addedItems;
		}

		let removedItems = ctrl.reviewCtrl.getRemovedCurrentAccessItems();
		if (removedItems != undefined && removedItems.length > 0 && JSON.stringify(removedItems) != JSON.stringify(oldRemovedItems)) {
			dataMap.removedItems = removedItems;
		}

		if (dataMap.addedItems != undefined || dataMap.removedItems != undefined) {
			//get the identities selected for which access is raised
			let idCtrl = angular.element('[ng-controller="AccessRequestSelectedIdentitiesCtrl as identitiesCtrl"]').scope();
			dataMap.selectedIdentities = idCtrl.identitiesCtrl.getIdentities();
			validateItems(dataMap);
		}
		else {
			if (document.getElementById("reviewBtnPlugin") != undefined) {
				jQuery("#reviewBtnPlugin").remove();
			}
			jQuery("#submitBtn").show();
		}
	}
};

function showReviewBtn() {
	if (document.getElementById("reviewBtnPlugin") == undefined) {
		jQuery("#submitBtn").hide();
		jQuery("#cancelBtn").parent().append('<button id="reviewBtnPlugin" class="btn btn-s-sm btn-white" type="button">Review</button>')
		$("#reviewBtnPlugin").unbind().click(function() {
			getSelectedItems();
		});
	}
}

//Script starts
jQuery(window).on('hashchange', function() {
	let locHash = location.hash;
	if (locHash.includes('review') && document.getElementById("reviewBtnPlugin") == undefined && showReview) {
		showReviewBtn(); // run the review at the page load

		//run the review if there are any changes in the dom (removed selected identites or removed any access(es))
		let selectedIdentitiesBtn = $("#selectedIdentitiesBtn")[0];
		let accessDiv = $(".col-xs-12.ng-scope")[1];
		let observer = new MutationObserver(function(mutations) {
			mutations.forEach(function(mutation) {
				if (mutation.removedNodes != undefined) {
					showReviewBtn();
				}
				else {
					showReview = false;
				}
			});
		});
		let config = {
			childList: false,
			subtree: true,
			attributes: false,
			characterData: true
		};

		// Keep observering the selectedIdentities and access removed, if any
		observer.observe(selectedIdentitiesBtn, config);
		observer.observe(accessDiv, config);
	}
	else if ((locHash.includes('selectUser') || locHash.includes('manageAccess') || locHash.includes('addAccess')) && document.getElementById("reviewBtnPlugin") != undefined) {
		//Remove Review button on selectUser and manageAccess page
		jQuery("#reviewBtnPlugin").remove();
	}
});
